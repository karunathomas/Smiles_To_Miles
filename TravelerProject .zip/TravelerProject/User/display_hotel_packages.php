<?php 
session_start();
$logid=$_SESSION["slogid"];
$place=$_GET["Place"];
$Rate=$_GET["Rate"];
$arry_rate=explode("-", $Rate);

?>
<h3>Package List</h3>
					<table class="table">
  <thead>
  <tr>
     <th>Place</th>
     <th>Hotel</th>
     <th>AC</th>
     <th>Restaurant</th>
     
       <th>Bar</th>
        <th>Room service</th>
         <th>Child friendly</th>
          <th>Pet friendly</th>
          <th>Wifi</th>
<th>Room Type</th>
     <th>Amount</th>
         
       
        <th>Book Now</th>
       
       
  </tr>
  </thead>
  <tbody>
<?php

include('../connect.php');
$res= mysqli_query($con,"select * from tbl_hotel_packages  inner join tbl_hotel on tbl_hotel_packages.Lic_No=tbl_hotel.Lic_No  inner join  tbl_place on tbl_hotel_packages.Place_id=tbl_place.place_id inner join tbl_district on tbl_place.district_id=tbl_district.district_id inner join tbl_state on tbl_state.state_id=tbl_district.state_id inner join tbl_countries on tbl_countries.country_id=tbl_state.country_id where tbl_hotel_packages.place_id=$place and tbl_hotel_packages.Amount between $arry_rate[0] and $arry_rate[1]");
//where tbl_travel_agency.login_id=$logid

while($row=mysqli_fetch_array($res))
{
	?>
	<tr>
<td><?php echo $row["place"]; ?> ,<?php echo $row["district"]; ?>, <?php echo $row["state"]; ?>,<?php echo $row["country_name"]; ?></td>
<td><?php echo $row["Ac"]; ?></td>
		<td><?php echo $row["Hotel_name"]; ?></td>
		
		<td><?php echo $row["Restaurant"]; ?></td>
		<td><?php echo $row["Bar"]; ?></td>
		<td><?php echo $row["Room_service"]; ?></td>
		<td><?php echo $row["Child_friendly"]; ?></td>
		<td><?php echo $row["Pet_friendly"]; ?></td>
		<td><?php echo $row["Wi_fi"]; ?></td>
		<td><?php echo $row["room_type"]; ?></td>
		<td><?php echo $row["Amount"]; ?></td>
		
		<td><a class="btn btn-primary" href="booking_hotel_start_date.php?pkgid=<?php echo $row["hotel_package_id"] ?>">Book Now</a></td>
		
		

	</tr>

	<?php
}
?>
</tbody></table>
