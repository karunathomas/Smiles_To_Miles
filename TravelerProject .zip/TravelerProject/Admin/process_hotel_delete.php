<?php
include('../connect.php');

$hotel_id=$_GET["hotel_id"];
$qry= mysqli_query($con,"delete from tbl_hotel_info where hotel_info_id=$hotel_id");

echo mysqli_error($con);
echo "<script>alert('Deleted  successfully......');
window.location='addhotel.php'</script>";
?>