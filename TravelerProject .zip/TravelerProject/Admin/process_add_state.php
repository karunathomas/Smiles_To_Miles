<?php
include('../connect.php');
$state=$_POST["state"];
$country=$_POST["country"];

$qry= mysqli_query($con,"insert into tbl_state(state,country_id)values('$state',$country)");

echo mysqli_error($con);
echo "<script>alert('Added successful......');
window.location='add_state.php'</script>";
?>