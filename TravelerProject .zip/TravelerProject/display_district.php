
									<option value="0">--Select--</option>
									<?php
									$state=$_GET["state"];
									
include('connect.php');

$res= mysqli_query($con,"select * from tbl_district where state_id=$state");
while($row=mysqli_fetch_array($res))
{
	?>
	<option value="<?php echo $row["district_id"]?>"><?php echo $row["district"]?></option>

	<?php
}


									?>