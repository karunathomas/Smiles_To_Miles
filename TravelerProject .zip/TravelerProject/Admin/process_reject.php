<?php
include('../connect.php');

$login_id=$_GET["login_id"];
$qry= mysqli_query($con,"update tbl_login set status='Rejected' where login_id=$login_id");

echo mysqli_error($con);
echo "<script>alert('Rejected successful......');
window.location='approve_user.php'</script>";
?>