<!DOCTYPE HTML>
<!--
	Aesthetic by gettemplates.co
	Twitter: http://twitter.com/gettemplateco
	URL: http://gettemplates.co
-->
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Traveler </title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Website Template by GetTemplates.co" />
	<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
	<meta name="author" content="GetTemplates.co" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="../css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="../css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="../css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="../css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="../css/magnific-popup.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="../css/bootstrap-datepicker.min.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="../css/style.css">

	<!-- Modernizr JS -->
	<script src="../js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="gtco-loader"></div>
	
	<div id="page">

	
	<!-- <div class="page-inner"> -->
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			
			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div id="gtco-logo"><a href="index.php">let's wonder where the wi-fi is weak <em></em></a></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					<ul>
	<li class="active"><a href="index.php">Home</a></li>
	<li><a href="approve_user.php">Approve</a></li>
								<li><a href="addhotel.php">Add Hotel</a></li>
								<li><a href="addsite.php">Add Tour Places</a></li>
								<li class="has-dropdown">
							<a>Location</a>
							<ul class="dropdown">
								<li><a href="add_state.php">Add State</a></li>
								<li><a href="add_district.php">Add District</a></li>
								<li><a href="add_place.php">Add Place</a></li>
								
							</ul>
						</li>
								<li><a href="../logout.php">Logout</a></li>
		</ul>	
				</div>
			</div>
			
		</div>
	</nav>
	
	<header id="gtco-header" class="gtco-cover gtco-cover-md" role="banner" style="background-image: url(../images/123.jpg)">
		<div class="overlay">                      </div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">
					

					<div class="row row-mt-15em">
						<div class="col-md-7 mt-text animate-box" data-animate-effect="fadeInUp">
							<h1><strong><em><font size="10" face="algerian">SMILES TO MILES.....</font></em></strong></h1>	
						</div>
						<div class="col-md-4 col-md-push-1 animate-box" data-animate-effect="fadeInRight">
							<!--iv class="form-wrap">
								<div class="tab">
                                <form id='login' action='login.php' method='post' accept-charset='UTF-8'>
                                <fieldset>
                                <legend>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Login</legend>
                                <input type='hidden' name='submitted' id='submitted' value='1'/>
                                <label for='username'>&nbsp;&nbsp;&nbsp;Username: </label>
                                <input type='text' name='username' maxlength="50"/></br></br>
                                <label for='password'>&nbsp;&nbsp;&nbsp;Password :</label>
                                <input type='password' name='password' id='password' maxlength="50"/>
                                </br></br>
                               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                               <input type='submit' name='submit' value='submit'/><strong></strong></fieldset> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="forget.php">Forget Password</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="reg.php">Sign Up</a></header>--><!--<div class="form-wrap">-->
								<!--<div class="tab"><center> <a href=""><input type="button" name="bs1" value="ADD"></a></center></br><center> <a href=""><input type="button" name="bs2" value="UPDATE"></a></center></br><center><a href=""><input type="button" name="bs3" value="DELETE" ></a></center></br><center><!--<a href="users.php"><input type="button" name="bs4" value="Users" ></a>--><!--</center>-->
                                </header>
					<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
  
  
                     <!--  <tr><td width="35%" height="115"><?php//echo $res[0];?></td><td width="65%">
                       <form action="adm1.php" method="post">
                       <input type="hidden" value="<?php //echo $res[1] ?>" name="t">
                       <input type="submit" value="details"></form></td></tr>
                       <?php// } ?>
                       </table>
                       
                       <?php
	//include('connect.php');
	//$qry=mysqli_query($con,"select * from hotel"); ?>
	  <table width="55%" height="121" align="center" cellpadding="20%">
   <!-
	
	<!-- jQuery -->
	<script src="../js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="../js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="../js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="../js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="../js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="../js/jquery.countTo.js"></script>

	<!-- Stellar Parallax -->
	<script src="../js/jquery.stellar.min.js"></script>

	<!-- Magnific Popup -->
	<script src="../js/jquery.magnific-popup.min.js"></script>
	<script src="../js/magnific-popup-options.js"></script>
	
	<!-- Datepicker -->
	<script src="../js/bootstrap-datepicker.min.js"></script>
	
<script src="../js/main.js"></script>
	<!-- Main -->
	
	 
                       
</body>
</html> 

