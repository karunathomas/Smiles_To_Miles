<?php
include('../connect.php');

$state_id=$_GET["state_id"];
$qry= mysqli_query($con,"delete from tbl_state where state_id=$state_id");

echo mysqli_error($con);
echo "<script>alert('Deleted  successfully......');
window.location='add_state.php'</script>";
?>