<?php
include('connect.php');
$hname=$_POST["hname"];
$licno=$_POST["licno"];
$place=$_POST["Place"];
$password=$_POST["password"];
$ownername=$_POST["ownername"];
$Website=$_POST["Website"];
$Pincode=$_POST["Pincode"];
$star_category=$_POST["star_category"];
$railway=$_POST["railway"];
$email=$_POST["email"];
$phno=$_POST["phno"];
  $qry3="select * from tbl_hotel where Lic_No=$licno";

$res= mysqli_query($con,$qry3);
$n=mysqli_num_rows($res);

if($n==0)
{


$r=mysqli_query($con,"insert into tbl_login(User_id,Password,User_type,status) values('$email','$password','3','Submitted')");
 $last_id = mysqli_insert_id($con);
  $qry1="insert into tbl_hotel(Hotel_name,Lic_No,city,Owner_id,Owner_name,Phone,Website,Pin,Star_cat,Railway,login_id)values('$hname',$licno,$place,'$email','$ownername',$phno,'$Website',$Pincode,$star_category,'$railway',$last_id )";
$qry= mysqli_query($con,$qry1);
echo "<script>alert('registration successful.......please login to continue');
window.location='hotels.php'</script>";
}
else
{
echo "<script>alert('Licence Number Already Exist');
window.location='hotels.php'</script>";
}


?>