<?php 
include('../connect.php');
session_start();
$logid=$_SESSION["slogid"];
$pkgid=$_POST['pkgid'];
$card=$_POST['card_name'];
$cardno=$_POST['card_number'];
	$cvvno=$_POST['cvv'];
	$date=date("Y-m-d");
	echo $bdate=$_POST["bdate"];
	$bd=explode("/", $bdate);
	echo $bd=$bd[2]."-".$bd[0]."-".$bd[1];
	$amount=$_POST['amount'];
	$rs=$_POST['card_type'];
	if($rs=="Credit")
	{
		$qry=mysqli_query($con,"select * from tbl_bank where card_type='Credit'");
		$rs=mysqli_fetch_array($qry);
		$cardname=$rs["card_name"];
		$cno=$rs["cardno"];
		$cvv=$rs["cvv"];
		$exp=$rs["expiry_date"];
		$inr=$rs["balance"];
		if($card==$cardname)
		{
		if($cardno==$cno)
		{ 
		if($cvvno==$cvv)
		{
			if($date<=$exp)
			{
				if($amount>$inr)
					
				{
					echo "<script> alert('Not Enough Cash in your Account!!!!!');window.location='book_travel_packages.php?amount=$amount&pkgid=$pkgid&date=$bdate'</script>";
				}
				else
				{
			    $r=$inr-$amount;
			   echo $q=mysqli_query($con,"update tbl_bank set balance='$r' where card_type='credit'");
			   $q1=mysqli_query($con,"insert into tbl_booking(booking_type,login_id ,Package_id,amount_paid,status,from_date,booking_date) values('Travel',$logid,$pkgid,$amount,'Paid','$bd','$date')");

	            echo mysqli_error($con);
				echo "<script> alert('successful');window.location='booking_travels.php'</script>";
				
				}
			}
			else
			{
				echo "<script> alert('card expiary date is exceeded');window.location='book_travel_packages.php?amount=$amount&pkgid=$pkgid&date=$bdate'</script>";
			}
		}
			else
			{
				echo "<script> alert('Invalid cvv no');window.location='book_travel_packages.php?amount=$amount&pkgid=$pkgid&date=$bdate'</script>";
			}
		}
		
		else
		{
			echo "<script> alert('Invalid cardno');window.location='book_travel_packages.php?amount=$amount&pkgid=$pkgid&date=$bdate'</script>";
		}
		}
		else{
			echo "<script> alert('Invalid cardname');window.location='book_travel_packages.php?amount=$amount&pkgid=$pkgid&date=$bdate'</script>";
		}
	}
	else
	{
		$qry=mysqli_query($con,"select * from tbl_bank where card_type='Debit'");
		$res=mysqli_fetch_array($qry);
		$cardname=$rs["card_name"];
		$cno=$rs["cardno"];
		$cvv=$rs["cvv"];
		$exp=$rs["expiry_date"];
		$inr=$rs["balance"];
		if($card==$cardname)
		{
			
		if($cardno==$cno)
		{ 
		if($cvvno==$cvv)
		{
			if($date<=$exp)
			{
				if($amount>$inr)
					
				{
					echo "<script> alert('Not Enough Cash in your Account!!!!!');

					window.location='book_travel_packages.php?amount=$amount&pkgid=$pkgid&date=$bdate'</script>";
				}
				else{
				
	 
	            $r=$inr-$amount;
			    $q=mysqli_query($con,"update tbl_bank set balance='$r' where card_type='Debit'");
			    $q1=mysqli_query($con,"insert into tbl_booking(booking_type,login_id ,Package_id,amount_paid,status,from_date,booking_date) values('Hotel',$logid,$pkgid,$amount,'Paid','$bd','$date')");

	            echo mysqli_error($con);
				echo "<script> alert('successful');window.location='booking_travels.php'</script>";
				}
			}
			else
			{
				echo "<script> alert('card expiary date is exceeded');
				window.location='book_travel_packages.php?amount=$amount&pkgid=$pkgid&date=$bdate'</script>";
			}
		}
			else
			{
				echo "<script> alert('Invalid cvv no');window.location='book_travel_packages.php?amount=$amount&pkgid=$pkgid&date=$bdate'</script>";
			}
		}
		
		else
		{
			echo "<script> alert('Invalid cardno');window.location='book_travel_packages.php?amount=$amount&pkgid=$pkgid&date=$bdate'</script>";
		}
		}
		else{
			echo "<script> alert('Invalid cardname');window.location='book_travel_packages.php?amount=$amount&pkgid=$pkgid&date=$bdate'</script>";
		}
	}