<!DOCTYPE HTML>
<!--
	Aesthetic by gettemplates.co
	Twitter: http://twitter.com/gettemplateco
	URL: http://gettemplates.co
-->
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Traveler </title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Website Template by GetTemplates.co" />
	<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
	<meta name="author" content="GetTemplates.co" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="../css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="../css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="../css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="../css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="../css/magnific-popup.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="../css/bootstrap-datepicker.min.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="../css/style.css">

	<!-- Modernizr JS -->
	<script src="../js/modernizr-2.6.2.min.js"></script>
	<script type="text/javascript" src="../Ajax/ajax.js"></script>
	<script type="text/javascript" src="../validation.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="gtco-loader">
	 
	</div>
	
	<div id="page">

	
	<!-- <div class="page-inner"> -->
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			
			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div id="gtco-logo"><a href="index.html">let's wonder where the wi-fi is weak <em></em></a></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					<ul>
	<li ><a href="index.php">Home</a></li>
	<li><a href="approve_user.php">Approve</a></li>
								<li class="active"><a href="addhotel.php">Add Hotel</a></li>
								<li><a href="addsite.php">Add Tour Places</a></li>
								<li class="has-dropdown">
							<a>Location</a>
							<ul class="dropdown">
								<li><a href="add_state.php">Add State</a></li>
								<li><a href="add_district.php">Add District</a></li>
								<li><a href="add_place.php">Add Place</a></li>
								
							</ul>
						</li>
								<li><a href="../logout.php">Logout</a></li>
		</ul>		
				</div>
			</div>
			
		</div>
	</nav>
	
	<header id="gtco-header" class="gtco-cover gtco-cover-sm" role="banner" style="background-image:url(../images/alappy.jpg)">
	  <div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">
					<div class="row row-mt-15em"><div class="col-md-7 mt-text animate-box" data-animate-effect="fadeInUp">
						
								</div>
					
				</div>
			</div>
		</div>
	</header>
	
	
	
	
	
	<div class="gtco-section border-bottom">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12">
					<div class="col-md-6 animate-box" style="width:30%">
					<h3>Add Hotel Info</h3>
					<form action="process_addhotel.php" name="f1" method="post" enctype="multipart/form-data">

<div class="row form-group">
							<div class="col-md-12">
								<label class="" for="country">Country</label>
								<select class="form-control" id="country" name="country" onchange="display_state()">
									<option value="0">--Select--</option>>
									<?php
									
include('../connect.php');

$res= mysqli_query($con,"select * from tbl_countries");
while($row=mysqli_fetch_array($res))
{
	?>
	<option value="<?php echo $row["country_id"]?>"><?php echo $row["country_name"]?></option>

	<?php
}


									?>
								</select>
								

							</div>
							
						</div>

								<div class="row form-group">
							<div class="col-md-12">
								<label class="" for="state">State</label>
								<select class="form-control" name="state"  id="state" onchange="display_district()"> 
									<option value="0">--Select--</option>>
									
								</select>
								

							</div>
							
						</div>

<div class="row form-group">
							<div class="col-md-12">
								<label class="" for="district" >District</label>
								<select class="form-control" id="district" name="district" onchange="display_place()">
									<option value="0">--Select--</option>>
									
								</select>
								

							</div>
							
						</div>
						<div class="row form-group">
							<div class="col-md-12">
								<label class="" for="place">place</label>
								
<select class="form-control" id="Place" name="Place">
									<option value="0">--Select--</option>>
									
								</select>
							</div>
							
						</div>

						<div class="row form-group">
							<div class="col-md-12">
								<label class="" for="name">Hotel Name</label>
								<input type="text" id="hname" name="hname" class="form-control" placeholder="Hotel Name">
								

							</div>
							
						</div>

						<div class="row form-group">
							<div class="col-md-12">
								<label class="" for="Licence">Hotel Image</label>
								<input name="file" type="file" value="CHOOSE IMAGE">
							</div>
						</div>

					<div class="row form-group">
							<div class="col-md-12">
								<label class="" for="Address">Address</label>
								<textarea name="Address" id="Address" cols="30" rows="10" class="form-control" placeholder="Address"></textarea>
							</div>
						</div>

					
						<div class="row form-group">
							<div class="col-md-12">
								<label class="" for="message">Description</label>
								<textarea name="description" id="description" cols="30" rows="10" class="form-control" placeholder="Write us something"></textarea>
							</div>
						</div>
						
						<div class="form-group">
							<input type="submit" value="Submit" class="btn btn-primary" onclick="return validate_add_hotel()">
						</div>

					</form>		
					


					
				</div>
				<div class="col-md-5 col-md-push-1 animate-box" style="width:70%">
					
					<h3>Hotel List</h3>
					<table class="table">
  <thead>
  <tr>
     <th>Hotel Name</th>
     <th>Description</th>
      <th>Hotel Address</th>
       <th>Photo</th>
          <th>Place</th>
       <th>Delete</th>
       
  </tr>
  </thead>
  <tbody>
<?php
$res= mysqli_query($con,"select * from tbl_hotel_info  inner join tbl_place on tbl_hotel_info.place_id=tbl_place.place_id inner join tbl_district on tbl_place.district_id=tbl_district.district_id inner join tbl_state on tbl_state.state_id=tbl_district.state_id inner join tbl_countries on tbl_countries.country_id=tbl_state.country_id");

while($row=mysqli_fetch_array($res))
{
	?>
	<tr><td><?php echo $row["Hotel_name"]; ?></td>
		<td><?php echo $row["description"]; ?></td>
		<td><?php echo $row["hotel_address"]; ?></td>
		<td><img width="150" height="100" src="hotel_uploads/<?php echo $row["filename"]; ?>"></td>
		<td><?php echo $row["place"]; ?> ,<?php echo $row["district"]; ?>, <?php echo $row["state"]; ?>,<?php echo $row["country_name"]; ?></td>
		<td><a href="process_hotel_delete.php?hotel_id=<?php echo $row["hotel_info_id"] ?>">Delete</a></td>
		
		

	</tr>

	<?php
}
?>
</tbody></table>


				</div>
				</div>
			</div>
		</div>
	</div>

	<footer id="gtco-footer" role="contentinfo" style="padding: 0">
		<div class="gtco-container">
			

			<div class="row copyright">
				<div class="col-md-12">
					<p class="pull-left">
						<small class="block">&copy; 2016 Free HTML5. All Rights Reserved.</small> 
						<small class="block">Designed by Istrox</small>
					</p>
					
				</div>
			</div>

		</div>
	</footer>
	<!-- </div> -->

	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<script src="../js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="../js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="../js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="../js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="../js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="../js/jquery.countTo.js"></script>

	<!-- Stellar Parallax -->
	<script src="../js/jquery.stellar.min.js"></script>

	<!-- Magnific Popup -->
	<script src="../js/jquery.magnific-popup.min.js"></script>
	<script src="../js/magnific-popup-options.js"></script>
	
	<!-- Datepicker -->
	<script src="../js/bootstrap-datepicker.min.js"></script>
	
<script src="../js/main.js"></script>

	</body>
</html>

