<?php
include('../connect.php');

$district_id=$_GET["district_id"];
$qry= mysqli_query($con,"delete from tbl_district where district_id=$district_id");

echo mysqli_error($con);
echo "<script>alert('Deleted  successfully......');
window.location='add_district.php'</script>";
?>