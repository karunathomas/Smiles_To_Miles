
									<option value="0">--Select--</option>
									<?php
									$district=$_GET["district"];
									
include('connect.php');

$res= mysqli_query($con,"select * from tbl_place where district_id=$district");
while($row=mysqli_fetch_array($res))
{
	?>
	<option value="<?php echo $row["place_id"]?>"><?php echo $row["place"]?></option>

	<?php
}


									?>