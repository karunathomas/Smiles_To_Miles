function validate_travel_agency()
{
	tname=document.getElementById("tname").value;
	if(tname=="" || !isNaN(tname)){
                                alert("Please Enter Name of Travel Agency");
                                document.f1.tname.focus();
                                return false;
                            } 
                            licno=document.getElementById("licno").value;
	if(licno==""){
                                alert("Please Enter Licence Number");
                                document.f1.licno.focus();
                                return false;
                            } 
                             date=document.getElementById("date").value;
	if(date==""){
                                alert("Please Enter Affiliated Date");
                                document.f1.date.focus();
                                return false;
                            } 
                             country=document.getElementById("country").value;
	if(country==0){
                                alert("Please choose Country");
                               
                                return false;
                            } 
                            state=document.getElementById("state").value;
	if(state==0){
                                alert("Please choose state");
                               
                                return false;
                            } 
                            district=document.getElementById("district").value;
	if(district==0){
                                alert("Please choose District");
                               
                                return false;
                            } 
                            Place=document.getElementById("Place").value;
	if(Place==0){
                                alert("Please choose Place");
                               
                                return false;
                            } 
                            ownername=document.getElementById("ownername").value;
	if(ownername=="" || !isNaN(ownername)){
                                alert("Please Enter Name of Owner Name");
                                document.f1.ownername.focus();
                                return false;
                            } 
                            var mail=document.getElementById("email").value;
                     
                            atpos=mail.indexOf("@");
                            dotpos=mail.indexOf(".");
                            
                            if((atpos<1)||(dotpos-atpos<2)){
                                
                                 alert("Please Provide your Valid Email");
                                 document.f1.email.focus();
                                 return false;
                            }
                            var pswd=document.getElementById("password").value;
                            
                            if(pswd==""){
                                alert("Please Enter your Password");
                                document.f1.password.focus();
                                return false;
                            }
                           
                            return true;
}
function validate_travels()
{
	t_name=document.getElementById("t_name").value;
	if(t_name=="" || !isNaN(t_name)){
                                alert("Please Enter Name of Travels");
                                document.f1.t_name.focus();
                                return false;
                            } 
                            licno=document.getElementById("lic_no").value;
	if(licno==""){
                                alert("Please Enter Licence Number");
                                document.f1.lic_no.focus();
                                return false;
                            } 
                            
                             country=document.getElementById("country").value;
	if(country==0){
                                alert("Please choose Country");
                               
                                return false;
                            } 
                            state=document.getElementById("state").value;
	if(state==0){
                                alert("Please choose state");
                               
                                return false;
                            } 
                            district=document.getElementById("district").value;
	if(district==0){
                                alert("Please choose District");
                               
                                return false;
                            } 
                            Place=document.getElementById("Place").value;
	if(Place==0){
                                alert("Please choose Place");
                               
                                return false;
                            } 
                            ownername=document.getElementById("ownername").value;
	if(ownername=="" || !isNaN(ownername)){
                                alert("Please Enter Name of Owner Name");
                                document.f1.ownername.focus();
                                return false;
                            } 
                            var mail=document.getElementById("email").value;
                     
                            atpos=mail.indexOf("@");
                            dotpos=mail.indexOf(".");
                            
                            if((atpos<1)||(dotpos-atpos<2)){
                                
                                 alert("Please Provide your Valid Email");
                                 document.f1.email.focus();
                                 return false;
                            }
                            var pswd=document.getElementById("password").value;
                            
                            if(pswd==""){
                                alert("Please Enter your Password");
                                document.f1.password.focus();
                                return false;
                            }
                           
                            return true;
}
function validate_hotels()
{
	hname=document.getElementById("hname").value;
	if(hname=="" || !isNaN(hname)){
                                alert("Please Enter Name of Hotels");
                                document.f1.hname.focus();
                                return false;
                            } 
                            licno=document.getElementById("licno").value;
	if(licno==""){
                                alert("Please Enter Licence Number");
                                document.f1.licno.focus();
                                return false;
                            } 
                            
                             country=document.getElementById("country").value;
	if(country==0){
                                alert("Please choose Country");
                               
                                return false;
                            } 
                            state=document.getElementById("state").value;
	if(state==0){
                                alert("Please choose state");
                               
                                return false;
                            } 
                            district=document.getElementById("district").value;
	if(district==0){
                                alert("Please choose District");
                               
                                return false;
                            } 
                            Place=document.getElementById("Place").value;
	if(Place==0){
                                alert("Please choose Place");
                               
                                return false;
                            } 
                            ownername=document.getElementById("ownername").value;
	if(ownername=="" || !isNaN(ownername)){
                                alert("Please Enter Name of Owner Name");
                                document.f1.ownername.focus();
                                return false;
                            } 
                            var mail=document.getElementById("email").value;
                     
                            atpos=mail.indexOf("@");
                            dotpos=mail.indexOf(".");
                            
                            if((atpos<1)||(dotpos-atpos<2)){
                                
                                 alert("Please Provide your Valid Email");
                                 document.f1.email.focus();
                                 return false;
                            }
var Website=document.getElementById("Website").value;
                            
                            if(Website==""){
                                alert("Please Enter your Website");
                                document.f1.Website.focus();
                                return false;
                            }

                             var phno=document.getElementById("phno").value;
     if(phno=="" || isNaN(phno) || phno.length!=10)
        {
            alert("Please Provide valid  Phone Number1");
            document.f1.phno.focus();
            return false;
        }
var Pincode=document.getElementById("Pincode").value;
     if(Pincode=="" || isNaN(Pincode) || Pincode.length!=6)
        {
            alert("Please Provide valid  Pincode");
            document.f1.Pincode.focus();
            return false;
        }
        var pswd=document.getElementById("password").value;
                            
                            if(pswd==""){
                                alert("Please Enter your Password");
                                document.f1.password.focus();
                                return false;
                            }
        var star_category=document.getElementById("star_category").value;
                            
                            if(star_category=="" || isNaN(star_category) ){
                                alert("Please Enter Star Category - (number)");
                                document.f1.star_category.focus();
                                return false;
                            }
                            var railway=document.getElementById("railway").value;
                            
                            if(railway==""){
                                alert("Please Enter Nearest railway");
                                document.f1.railway.focus();
                                return false;
                            }
                            
                           
                            return true;
}
function validate_users()
{
	fname=document.getElementById("fname").value;
	if(fname=="" || !isNaN(fname)){
                                alert("Please Enter first name");
                                document.f1.fname.focus();
                                return false;
                            } 
                            lname=document.getElementById("lname").value;
	if(lname=="" || !isNaN(lname)){
                                alert("Please Enter last name");
                                document.f1.lname.focus();
                                return false;
                            } 
                            var phno=document.getElementById("phno").value;
     if(phno=="" || isNaN(phno) || phno.length!=10)
        {
            alert("Please Provide valid  Phone Number");
            document.f1.phno.focus();
            return false;
        }
        var mail=document.getElementById("email").value;
                     
                            atpos=mail.indexOf("@");
                            dotpos=mail.indexOf(".");
                            
                            if((atpos<1)||(dotpos-atpos<2)){
                                
                                 alert("Please Provide your Valid Email");
                                 document.f1.email.focus();
                                 return false;
                            }
                            var pswd=document.getElementById("password").value;
                            
                            if(pswd==""){
                                alert("Please Enter your Password");
                                document.f1.password.focus();
                                return false;
                            }
}
function validate_add_hotel()
{
  country=document.getElementById("country").value;
    if(country==0){
                                alert("Please choose Country");
                               
                                return false;
                            } 
                            state=document.getElementById("state").value;
    if(state==0){
                                alert("Please choose state");
                               
                                return false;
                            } 
                            district=document.getElementById("district").value;
    if(district==0){
                                alert("Please choose District");
                               
                                return false;
                            } 
                            Place=document.getElementById("Place").value;
    if(Place==0){
                                alert("Please choose Place");
                               
                                return false;
                            } 
                            hname=document.getElementById("hname").value;
    if(hname=="" || !isNaN(hname)){
                                alert("Please Enter Hotel Name");
                                document.f1.hname.focus();
                                return false;
                            } 
                            
                            
                            
                             Address=document.getElementById("Address").value;
    if(Address=="" || !isNaN(Address)){
                                alert("Please Enter Address");
                                document.f1.Address.focus();
                                return false;
                            } 
                             description=document.getElementById("description").value;
    if(description=="" || !isNaN(description)){
                                alert("Please Enter Description");
                                document.f1.description.focus();
                                return false;
                            } 
                            
                            return true;  
}
function validate_addsite()
{
 country=document.getElementById("country").value;
    if(country==0){
                                alert("Please choose Country");
                               
                                return false;
                            } 
                            state=document.getElementById("state").value;
    if(state==0){
                                alert("Please choose state");
                               
                                return false;
                            } 
                            district=document.getElementById("district").value;
    if(district==0){
                                alert("Please choose District");
                               
                                return false;
                            } 
                            Place=document.getElementById("Place").value;
    if(Place==0){
                                alert("Please choose Place");
                               
                                return false;
                            }    
sname=document.getElementById("sname").value;
    if(sname=="" || !isNaN(sname)){
                                alert("Please Enter Site Name");
                                document.f1.sname.focus();
                                return false;
                            } 
                            
                            
                            
                             Address=document.getElementById("Address").value;
    if(Address=="" || !isNaN(Address)){
                                alert("Please Enter Address");
                                document.f1.Address.focus();
                                return false;
                            } 
                             description=document.getElementById("description").value;
    if(description=="" || !isNaN(description)){
                                alert("Please Enter Description");
                                document.f1.description.focus();
                                return false;
                            } 
                            
                            return true;  
}
function validate_state()
{
    country=document.getElementById("country").value;
    if(country==0){
                                alert("Please choose Country");
                               
                                return false;
                            } 
                             state=document.getElementById("state").value;
    if(state=="" || !isNaN(state)){
                                alert("Please Enter State");
                                document.f1.state.focus();
                                return false;
                            } 
                            return true;
}
function validate_district()
{
    country=document.getElementById("country").value;
    if(country==0){
                                alert("Please choose Country");
                               
                                return false;
                            } 
                            state=document.getElementById("state").value;
    if(state==0){
                                alert("Please choose state");
                               
                                return false;
                            } 
                             district=document.getElementById("district").value;
    if(district=="" || !isNaN(district)){
                                alert("Please Enter District");
                                document.f1.district.focus();
                                return false;
                            } 
                            return true;
}
function validate_add_place()
{
    country=document.getElementById("country").value;
    if(country==0){
                                alert("Please choose Country");
                               
                                return false;
                            } 
                            state=document.getElementById("state").value;
    if(state==0){
                                alert("Please choose state");
                               
                                return false;
                            } 
                              district=document.getElementById("district").value;
    if(district==0){
                                alert("Please choose District");
                               
                                return false;
                            } 
                            place=document.getElementById("place").value;
    if(place=="" || !isNaN(place)){
                                alert("Please Enter Place");
                                document.f1.place.focus();
                                return false;
                            } 
}
function validate_travel_agency_package()
{
    country=document.getElementById("country").value;
    if(country==0){
                                alert("Please choose Country");
                               
                                return false;
                            } 
                            state=document.getElementById("state").value;
    if(state==0){
                                alert("Please choose state");
                               
                                return false;
                            } 
                            district=document.getElementById("district").value;
    if(district==0){
                                alert("Please choose District");
                               
                                return false;
                            } 
                            Place=document.getElementById("Place").value;
    if(Place==0){
                                alert("Please choose Place");
                               
                                return false;
                            } 
                             num_members=document.getElementById("num_members").value;
    if(num_members=="" || isNaN(num_members)){
                                alert("Please Enter Members");
                                document.f1.num_members.focus();
                                return false;
                            } 
                             num_days=document.getElementById("num_days").value;
    if(num_days=="" || isNaN(num_days)){
                                alert("Please Enter number of days");
                                document.f1.num_days.focus();
                                return false;
                            } 
                            num_nights=document.getElementById("num_nights").value;
    if(num_nights=="" || isNaN(num_nights)){
                                alert("Please Enter number of nights");
                                document.f1.num_nights.focus();
                                return false;
                            } 
                            stay_amount=document.getElementById("stay_amount").value;
    if(stay_amount=="" || isNaN(stay_amount)){
                                alert("Please Enter Stay amount");
                                document.f1.stay_amount.focus();
                                return false;
                            } 
                            description=document.getElementById("description").value;
    if(description=="" || !isNaN(description)){
                                alert("Please Enter Description");
                                document.f1.description.focus();
                                return false;
                            } 
                            

                            return true;
}
function validate_edit_TA_packages()
{
    num_members=document.getElementById("num_members").value;
    if(num_members=="" || isNaN(num_members)){
                                alert("Please Enter Members");
                                document.f1.num_members.focus();
                                return false;
                            } 
                             num_days=document.getElementById("num_days").value;
    if(num_days=="" || isNaN(num_days)){
                                alert("Please Enter number of days");
                                document.f1.num_days.focus();
                                return false;
                            } 
                            num_nights=document.getElementById("num_nights").value;
    if(num_nights=="" || isNaN(num_nights)){
                                alert("Please Enter number of nights");
                                document.f1.num_nights.focus();
                                return false;
                            } 
                            stay_amount=document.getElementById("stay_amount").value;
    if(stay_amount=="" || isNaN(stay_amount)){
                                alert("Please Enter Stay amount");
                                document.f1.stay_amount.focus();
                                return false;
                            } 
                            description=document.getElementById("description").value;
    if(description=="" || !isNaN(description)){
                                alert("Please Enter Description");
                                document.f1.description.focus();
                                return false;
                            }   
}
function validate_add_travel_package()
{
     vehicle=document.getElementById("vehicle").value;
    if(vehicle==0){
                                alert("Please Enter Vehicle");
                                document.f1.vehicle.focus();
                                return false;
                            } 
                            scapacity=document.getElementById("scapacity").value;
    if(scapacity=="" || isNaN(scapacity)){
                                alert("Please Enter Seat Capacity");
                                document.f1.scapacity.focus();
                                return false;
                            }   
                             amount=document.getElementById("amount").value;
    if(amount=="" || isNaN(amount)){
                                alert("Please Enter Amount");
                                document.f1.amount.focus();
                                return false;
                            }
                             vnumber=document.getElementById("vnumber").value;
    if(vnumber==""){
                                alert("Please Enter Vehicle Number");
                                document.f1.amount.focus();
                                return false;
                            }
}
function validate_edit_travels_package()
{
    scapacity=document.getElementById("scapacity").value;
    if(scapacity=="" || isNaN(scapacity)){
                                alert("Please Enter Seat Capacity");
                                document.f1.scapacity.focus();
                                return false;
                            }   
                             amount=document.getElementById("amount").value;
    if(amount=="" || isNaN(amount)){
                                alert("Please Enter Amount");
                                document.f1.amount.focus();
                                return false;
                            }
                             vnumber=document.getElementById("vnumber").value;
    if(vnumber==""){
                                alert("Please Enter Vehicle Number");
                                document.f1.amount.focus();
                                return false;
                            }
}
function validate_add_hotel_package()
 {

    country=document.getElementById("country").value;
    if(country==0){
                                alert("Please choose Country");
                               
                                return false;
                            } 
                            state=document.getElementById("state").value;
    if(state==0){
                                alert("Please choose state");
                               
                                return false;
                            } 
                            district=document.getElementById("district").value;
    if(district==0){
                                alert("Please choose District");
                               
                                return false;
                            } 
                            Place=document.getElementById("Place").value;
    if(Place==0){
                                alert("Please choose Place");
                               
                                return false;
                            } 

                            if(document.f1.air[0].checked==false && document.f1.air[0].checked==false)
                            {

                                alert("Please choose AC/Non Ac");
                               
                                return false;  
                            }
                            if(document.f1.r1[0].checked==false && document.f1.r1[0].checked==false)
                            {

                                alert("Please choose Restaurant or not");
                               
                                return false;  
                            }
                            if(document.f1.Bar[0].checked==false && document.f1.Bar[0].checked==false)
                            {

                                alert("Please choose Bar or Not");
                               
                                return false;  
                            }
                            if(document.f1.Roomservice[0].checked==false && document.f1.Roomservice[0].checked==false)
                            {

                                alert("Please choose Roomservice or Not");
                               
                                return false;  
                            }
                            if(document.f1.Child_friendly[0].checked==false && document.f1.Child_friendly[0].checked==false)
                            {

                                alert("Please choose Child friendly or Not");
                               
                                return false;  
                            }
                            if(document.f1.pet_friendly[0].checked==false && document.f1.pet_friendly[0].checked==false)
                            {

                                alert("Please choose pet friendly or Not");
                               
                                return false;  
                            }
                            if(document.f1.wifi[0].checked==false && document.f1.wifi[0].checked==false)
                            {

                                alert("Please choose wifi or Not");
                               
                                return false;  
                            }
                            rooms=document.getElementById("rooms").value;
    if(rooms==0){
                                alert("Please choose type of rooms");
                               
                                return false;
                            }
                             amount=document.getElementById("amount").value;
    if(amount=="" || isNaN(amount)){
                                alert("Please Enter Amount");
                                document.f1.amount.focus();
                                return false;
                            } 
 }
 function validate_tour_planner()
 {
    place=document.getElementById("place").value;
    if(place==""){
                                alert("Please Enter place");
                                document.f1.place.focus();
                                return false;
                            } 
 }
 function validate_change_password()
 {
     userid=document.getElementById("userid").value;
    if(userid==""){
                                alert("Please Enter User Id");
                                document.f1.userid.focus();
                                return false;
                            } 
                            cpassword=document.getElementById("cpassword").value;
    if(cpassword==""){
                                alert("Please Enter Current Password");
                                document.f1.cpassword.focus();
                                return false;
                            } 
                            newpassword=document.getElementById("newpassword").value;
    if(newpassword==""){
                                alert("Please Enter New Password");
                                document.f1.newpassword.focus();
                                return false;
                            } 
 }
function validate_ta_start_date()
{
     date=document.getElementById("date").value;
    if(date==""){
                                alert("Please Enter Date");
                                document.f1.date.focus();
                                return false;
                            } 
}
function validate_book_travel_agency_packages()
{
    card_type=document.getElementById("card_type").value;
    if(card_type==0){
                                alert("Please choose card type");
                               
                                return false;
                            } 
                            card_name=document.getElementById("card_name").value;
    if(card_name=="" ){
                                alert("Please Enter Card Name");
                                document.f1.card_name.focus();
                                return false;
                            } 
                             card_number=document.getElementById("card_number").value;
    if(card_number=="" || isNaN(card_number)){
                                alert("Please Enter valid Card Number");
                                document.f1.card_number.focus();
                                return false;
                            } 
                            cvv=document.getElementById("cvv").value;
    if(cvv=="" || isNaN(cvv)){
                                alert("Please Enter valid cvv");
                                document.f1.cvv.focus();
                                return false;
                            } 
}