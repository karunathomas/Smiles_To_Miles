<?php 
session_start();
$logid=$_SESSION["slogid"];
$place=$_GET["Place"];
$Rate=$_GET["Rate"];
$arry_rate=explode("-", $Rate);

?>
<h3>Package List</h3>
					<table class="table">
  <thead>
  <tr>
     <th>Place</th>
     <th>Members</th>
     
       <th>Photo</th>
         
       <th>More Details</th>
        <th>Book Now</th>
       
       
  </tr>
  </thead>
  <tbody>
<?php

include('../connect.php');
$res= mysqli_query($con,"select * from tbl_travel_agency_packages  inner join tbl_travel_agency on tbl_travel_agency_packages.Lic_No=tbl_travel_agency.Lic_No inner join  tbl_place on tbl_travel_agency_packages.Place_id=tbl_place.place_id inner join tbl_district on tbl_place.district_id=tbl_district.district_id inner join tbl_state on tbl_state.state_id=tbl_district.state_id inner join tbl_countries on tbl_countries.country_id=tbl_state.country_id where tbl_travel_agency_packages.Place_id=$place and tbl_travel_agency_packages.S_amount+tbl_travel_agency_packages.F_amount+tbl_travel_agency_packages.B_amount between $arry_rate[0] and $arry_rate[1]");
//where tbl_travel_agency.login_id=$logid

while($row=mysqli_fetch_array($res))
{
	?>
	<tr>
<td><?php echo $row["place"]; ?> ,<?php echo $row["district"]; ?>, <?php echo $row["state"]; ?>,<?php echo $row["country_name"]; ?></td>
		<td><?php echo $row["Members"]; ?></td>
		
		

		<td><img width="150" height="100" src="../Travel_Agency/package_uploads/<?php echo $row["Images"]; ?>"></td>
		<td><a class="btn btn-primary" href="more_travel_agency_packages.php?pkgid=<?php echo $row["Travel_agency_package_id"] ?>">More Details</a></td>
		<td><a class="btn btn-primary" href="booking_travel_agency_start_date.php?pkgid=<?php echo $row["Travel_agency_package_id"] ?>">Book Now</a></td>
		
		

	</tr>

	<?php
}
?>
</tbody></table>
