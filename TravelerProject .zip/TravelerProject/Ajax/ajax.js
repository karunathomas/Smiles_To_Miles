function display_state()
{
  var country=document.getElementById("country").value;
 

    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('state').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_state.php?country="+country,true);
  xmlhttp.send();

}
function display_district()
{
  var state=document.getElementById("state").value;
 

    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('district').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_district.php?state="+state,true);
  xmlhttp.send();

}
function display_place()
{
 var district=document.getElementById("district").value;
 

    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('Place').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_place.php?district="+district,true);
  xmlhttp.send();
 
}
function display_users()
{
   var utype=document.getElementById("utype").value;
 

    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_users.php?utype="+utype,true);
  xmlhttp.send();
}
function display_ta_packages()
{
   var Place=document.getElementById("Place").value;
    var Rate=document.getElementById("Rate").value;
    if(Place==0 || Rate==0)
    {
      alert("Please choose all fields");
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_ta_packages.php?Place="+Place+"&Rate="+Rate,true);
  xmlhttp.send();
}
}
function display_booking()
{
   var date=document.getElementById("date").value;
 
if(date=="")
{
    document.getElementById('error').innerHTML="Please Choose Date";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('res').innerHTML=xmlhttp.responseText;
       document.getElementById('error').innerHTML="";
   
    }
  }
  xmlhttp.open("GET","display_booking.php?date="+date,true);
  xmlhttp.send();
}
}
function display_hotel_packages()
{
   var Place=document.getElementById("Place").value;
    var Rate=document.getElementById("Rate").value;
if(Place==0 || Rate==0 )
    {
      alert("Please choose all fields");
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_hotel_packages.php?Place="+Place+"&Rate="+Rate,true);
  xmlhttp.send();
}
}
function display_travels_packages()
{
   var Place=document.getElementById("Place").value;
    var Rate=document.getElementById("Rate").value;
     var appdistance=document.getElementById("appdistance").value;
      var vehicle=document.getElementById("vehicle").value;
   
if(Place==0 || Rate==0  || Rate=="" || vehicle==0)
    {
      alert("Please choose all fields");
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_travels_packages.php?Place="+Place+"&Rate="+Rate+"&appdistance="+appdistance+"&vehicle="+vehicle,true);
  xmlhttp.send();
}
}