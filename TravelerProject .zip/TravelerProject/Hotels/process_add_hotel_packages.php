
<?php
session_start();
$logid=$_SESSION["slogid"];
include('../connect.php');
$Lic_No="";
 $sql="select * from tbl_hotel where login_id=$logid";
$res= mysqli_query($con,$sql);
while($row=mysqli_fetch_array($res))
{
 $Lic_No=$row["Lic_No"];
}
$Place=$_POST["Place"];
$air=$_POST["air"];
$resturant=$_POST["r1"];
$Bar=$_POST["Bar"];
$Roomservice=$_POST["Roomservice"];
$Child_friendly=$_POST["Child_friendly"];
$pet_friendly=$_POST["pet_friendly"];
$wifi=$_POST["wifi"];
$rooms=$_POST["rooms"];
$amount=$_POST["amount"];

 $qry= mysqli_query($con,"insert into tbl_hotel_packages(Lic_No, Ac, Restaurant, Bar, Room_service, Child_friendly, Pet_friendly, Wi_fi, room_type, Amount,place_id)values('$Lic_No','$air','$resturant','$Bar','$Roomservice','$Child_friendly','$pet_friendly','$wifi','$rooms',$amount,$Place)");

echo mysqli_error($con);
echo "<script>alert('Details Added successful......');
window.location='add_package.php'</script>";

?>