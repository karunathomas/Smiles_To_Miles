
									<?php

include('../connect.php');
									$utype=$_GET["utype"];
									if($utype==1)
									{
?>
<table class="table">
  <thead>
  <tr>
     <th>Agency Name</th>
     <th>Licence Number</th>
      <th>Owner Name</th>
       <th>Owner Email Id</th>
          <th>Place</th>
       <th>Approve</th>
       <th>Reject</th>
  </tr>
  </thead>
  <tbody>
<?php
$res= mysqli_query($con,"select * from tbl_login inner join tbl_travel_agency on tbl_login.login_id= tbl_travel_agency.login_id inner join tbl_place on tbl_travel_agency.place_id=tbl_place.place_id inner join tbl_district on tbl_place.district_id=tbl_district.district_id inner join tbl_state on tbl_state.state_id=tbl_district.state_id inner join tbl_countries on tbl_countries.country_id=tbl_state.country_id where tbl_login.status='Submitted'");
while($row=mysqli_fetch_array($res))
{
	?>
	<tr><td><?php echo $row["Agency_Name"]; ?></td>
		<td><?php echo $row["Lic_No"]; ?></td>
		<td><?php echo $row["Owner_name"]; ?></td>
		<td><?php echo $row["Owner_id"]; ?></td>
		<td><?php echo $row["place"]; ?> ,<?php echo $row["district"]; ?>, <?php echo $row["state"]; ?>,<?php echo $row["country_name"]; ?></td>
		<td><a href="process_approve.php?login_id=<?php echo $row["login_id"] ?>">Approve</a></td>
		<td><a href="process_reject.php?login_id=<?php echo $row["login_id"] ?>">Reject</a></td>
		

	</tr>

	<?php
}
?>
</tbody></table>
<?php

		}
		 if($utype==2)
		{

?>
<table class="table">
  <thead>
  <tr>
     <th>Travel Name</th>
     <th>Licence Number</th>
      <th>Owner Name</th>
       <th>Owner Email Id</th>
       <th>Place</th>
       <th>Approve</th>
       <th>Reject</th>
  </tr>
  </thead>
  <tbody>
<?php
$res= mysqli_query($con,"select * from tbl_travels inner join tbl_login on tbl_login.login_id= tbl_travels.login_id inner join tbl_place on tbl_place.place_id=tbl_travels.place inner join tbl_district on tbl_place.district_id=tbl_district.district_id inner join tbl_state on tbl_state.state_id=tbl_district.state_id inner join tbl_countries on tbl_countries.country_id=tbl_state.country_id  where tbl_login.status='Submitted'");
while($row=mysqli_fetch_array($res))
{
	?>
	<tr><td><?php echo $row["Travel_name"]; ?></td>
		<td><?php echo $row["Lic_No"]; ?></td>
		<td><?php echo $row["Owner_name"]; ?></td>
		<td><?php echo $row["Owner_id"]; ?></td>
		<td><?php echo $row["place"]; ?> ,<?php echo $row["district"]; ?>, <?php echo $row["state"]; ?>,<?php echo $row["country_name"]; ?></td>
		<td><a href="process_approve.php?login_id=<?php echo $row["login_id"] ?>">Approve</a></td>
		<td><a href="process_reject.php?login_id=<?php echo $row["login_id"] ?>">Reject</a></td>
		

	</tr>

	<?php
}
?>
</tbody></table>
<?php
		}	
		if($utype==3)
		{

?>
<table class="table">
  <thead>
  <tr>
     <th>Hotel Name</th>
     <th>Licence Number</th>
      <th>Owner Name</th>
       <th>Owner Email Id</th>
       <th>Place</th>
       <th>Approve</th>
       <th>Reject</th>
  </tr>
  </thead>
  <tbody>
<?php
$res= mysqli_query($con,"select * from tbl_hotel inner join tbl_login on tbl_login.login_id= tbl_hotel.login_id inner join tbl_place on tbl_place.place_id=tbl_hotel.city inner join tbl_district on tbl_place.district_id=tbl_district.district_id inner join tbl_state on tbl_state.state_id=tbl_district.state_id inner join tbl_countries on tbl_countries.country_id=tbl_state.country_id  where tbl_login.status='Submitted'");
while($row=mysqli_fetch_array($res))
{
	?>
	<tr><td><?php echo $row["Hotel_name"]; ?></td>
		<td><?php echo $row["Lic_No"]; ?></td>
		<td><?php echo $row["Owner_name"]; ?></td>
	
<td><?php echo $row["Phone"]; ?></td>
<td><?php echo $row["Website"]; ?></td>


		<td><?php echo $row["place"]; ?> ,<?php echo $row["district"]; ?>, <?php echo $row["state"]; ?>,<?php echo $row["country_name"]; ?></td>
		<td><a href="process_approve.php?login_id=<?php echo $row["login_id"] ?>">Approve</a></td>
		<td><a href="process_reject.php?login_id=<?php echo $row["login_id"] ?>">Reject</a></td>
		

	</tr>

	<?php
}
?>
</tbody></table>
<?php
		}	
								?>