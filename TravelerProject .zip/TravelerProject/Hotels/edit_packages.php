<?php 
session_start();
$logid=$_SESSION["slogid"];
?>
<!DOCTYPE HTML>
<!--
	Aesthetic by gettemplates.co
	Twitter: http://twitter.com/gettemplateco
	URL: http://gettemplates.co
-->
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Traveler </title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Website Template by GetTemplates.co" />
	<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
	<meta name="author" content="GetTemplates.co" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="../css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="../css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="../css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="../css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="../css/magnific-popup.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="../css/bootstrap-datepicker.min.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="../css/style.css">

	<!-- Modernizr JS -->
	<script src="../js/modernizr-2.6.2.min.js"></script>
	<script type="text/javascript" src="../Ajax/ajax.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="gtco-loader">
	 
	</div>
	
	<div id="page">

	
	<!-- <div class="page-inner"> -->
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			
			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div id="gtco-logo"><a href="index.html">let's wonder where the wi-fi is weak <em></em></a></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					<ul>
	<li ><a href="index.php">Home</a></li>
	<li class="active"><a href="add_package.php">Package</a></li>
								<li ><a href="booking.php">Booking</a></li>
								
								<li><a href="../logout.php">Logout</a></li>
		</ul>	
				</div>
			</div>
			
		</div>
	</nav>
	
	<header id="gtco-header" class="gtco-cover gtco-cover-sm" role="banner" style="background-image:url(../images/123.jpg)">
	  <div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">
					<div class="row row-mt-15em"><div class="col-md-7 mt-text animate-box" data-animate-effect="fadeInUp">
						
								</div>
					
				</div>
			</div>
		</div>
	</header>
	
	
	
	
	
	<div class="gtco-section border-bottom">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12">
					<div class="col-md-6 animate-box" style="width:30%">
					
					
				</div>
				<h3>Add Packages</h3>
					
				<div class="col-md-5 col-md-push-1 animate-box" style="width:70%">
					<?php $pkgid=$_GET["pkgid"];
include('../connect.php');


			$res= mysqli_query($con,"select * from tbl_travel_agency_packages  where Travel_agency_package_id=$pkgid");

while($row=mysqli_fetch_array($res))
{?>
					<form action="process_update_packages.php" method="post" enctype="multipart/form-data">


						<div class="row form-group">
							<div class="col-md-12">
								<label class="" for="name">Number of Members</label>
								<input type="text" id="num_members" name="num_members" value="<?php echo $row["Members"]; ?>" class="form-control" placeholder="Number of Members">
								

							</div>
							
						</div>
<div class="row form-group">
							<div class="col-md-12">
								<label class="" for="name">Number of days</label>
								<input type="text" id="num_days" value="<?php echo $row["No_days"]; ?>" name="num_days" class="form-control" placeholder="Number of days">
								

							</div>
							
						</div>

						<div class="row form-group">
							<div class="col-md-12">
								<label class="" for="name">Number of nights</label>
								<input type="text" id="num_nights" value="<?php echo $row["No_nights"]; ?>" name="num_nights" class="form-control" placeholder="Number of nights">
								

							</div>
							
						</div>
						<div class="row form-group">
							<div class="col-md-12">
								<label class="" for="name">Stay Amount</label>
								<input type="text" id="stay_amount" value="<?php echo $row["S_amount"]; ?>" name="stay_amount" class="form-control" placeholder="Stay Amount">
								

							</div>
							
						</div>

						<div class="row form-group">
							<div class="col-md-12">
								<label class="" for="name">Food Amount</label>
								<input type="text" id="food_amount" name="food_amount"  class="form-control"  value="<?php echo $row["F_amount"]; ?>" placeholder="Food Amount">
								

							</div>
							
						</div>

					<div class="row form-group">
							<div class="col-md-12">
								<label class="" for="name">Bus Amount</label>
								<input type="text" id="bus_amount"  value="<?php echo $row["B_amount"]; ?>" name="bus_amount" class="form-control" placeholder="Bus Amount">
								

							</div>
							
						</div>

						<div class="row form-group">
							<div class="col-md-12">
								<label class="" for="name">Train Amount</label>
								<input type="text" id="train_amount"  value="<?php echo $row["T_amount"]; ?>" name="train_amount" class="form-control" placeholder="Train Amount">
								

							</div>
							
						</div>
						<div class="row form-group">
							<div class="col-md-12">
								<label class="" for="message">Description</label>
								<textarea name="description" id="description" cols="30" rows="10" class="form-control" placeholder="Write us something"> <?php echo $row["Description"]?></textarea><input type="hidden" name="pkgid" value="<?php echo $pkgid ?>">
							</div>
						</div>
						

					

						<div class="form-group">
							<input type="submit" value="Submit" class="btn btn-primary">
						</div>

					</form>		
					

<?php } ?>
					


				</div>
				</div>
			</div>
		</div>
	</div>

	<footer id="gtco-footer" role="contentinfo" style="padding: 0">
		<div class="gtco-container">
			

			<div class="row copyright">
				<div class="col-md-12">
					<p class="pull-left">
						<small class="block">&copy; 2016 Free HTML5. All Rights Reserved.</small> 
						<small class="block">Designed by Istrox</small>
					</p>
					
				</div>
			</div>

		</div>
	</footer>
	<!-- </div> -->

	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<script src="../js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="../js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="../js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="../js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="../js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="../js/jquery.countTo.js"></script>

	<!-- Stellar Parallax -->
	<script src="../js/jquery.stellar.min.js"></script>

	<!-- Magnific Popup -->
	<script src="../js/jquery.magnific-popup.min.js"></script>
	<script src="../js/magnific-popup-options.js"></script>
	
	<!-- Datepicker -->
	<script src="../js/bootstrap-datepicker.min.js"></script>
	
<script src="../js/main.js"></script>

	</body>
</html>

