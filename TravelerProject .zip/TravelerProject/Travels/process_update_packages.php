
<?php
session_start();
$logid=$_SESSION["slogid"];
include('../connect.php');

$pkgid=$_POST["pkgid"];
$amount=$_POST["amount"];
$vnumber=$_POST["vnumber"];
$scapacity=$_POST["scapacity"];


 $qry= mysqli_query($con,"update  tbl_travel_packages set  Vehicle_number='$vnumber',  km_amount=$amount,Seating_capacity=$scapacity where travel_package_id=$pkgid");

echo mysqli_error($con);
echo "<script>alert('Added successful......');
window.location='add_package.php'</script>";

?>