<?php
include('../connect.php');

$district=$_POST["district"];
$place=$_POST["place"];
$qry= mysqli_query($con,"insert into tbl_place(place,district_id)values('$place',$district)");

echo mysqli_error($con);
echo "<script>alert('Added successful......');
window.location='add_place.php'</script>";
?>