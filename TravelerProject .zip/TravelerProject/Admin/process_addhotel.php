<?php
include('../connect.php');
$hname=$_POST["hname"];
$place=$_POST["Place"];
$description=$_POST["description"]; 
$Address=$_POST["Address"]; 



 $i = 0; 
    $dir = 'hotel_uploads/';
    if ($handle = opendir($dir)) {
        while (($file = readdir($handle)) !== false){
            if (!in_array($file, array('.', '..')) && !is_dir($dir.$file)) 
                $i++;
        }
    }

$target_dir = "hotel_uploads/";
 $target_file = $target_dir . basename($_FILES["file"]["name"]);
$uploadOk = 1;
echo $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
 $target_file1 = $target_dir .$i. basename($_FILES["file"]["name"]);

// Check file size
if ($_FILES["file"]["size"] >100000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" && $imageFileType != "mov" && $imageFileType != "mp4" && $imageFileType != "3gp" && $imageFileType != "ogg")
 {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";

    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "<script>alert('Not a valid Image');
window.location='addhotel.php'</script>";
// if everything is ok, try to upload file
} else {
   move_uploaded_file($_FILES["file"]["tmp_name"], $target_file1);
    $photo=$i.$_FILES["file"]["name"];

  echo $qry1="insert into tbl_hotel_info(Hotel_name,place_id,description,hotel_address,filename)values('$hname',$place,'$description','$Address',  '$photo')";
$qry= mysqli_query($con,$qry1);
echo "<script>alert('Hotel Information Added successful');
window.location='addhotel.php'</script>";
}

 



?>