
<?php
session_start();
$logid=$_SESSION["slogid"];
include('../connect.php');

$i = 0; 
    $dir = 'package_uploads/';
    if ($handle = opendir($dir)) {
        while (($file = readdir($handle)) !== false){
            if (!in_array($file, array('.', '..')) && !is_dir($dir.$file)) 
                $i++;
        }
    }
  
$target_dir = "package_uploads/";
 $target_file = $target_dir . basename($_FILES["file"]["name"]);
$uploadOk = 1;
echo $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
 $target_file1 = $target_dir .$i. basename($_FILES["file"]["name"]);

// Check file size
if ($_FILES["file"]["size"] >100000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" && $imageFileType != "mov" && $imageFileType != "mp4" && $imageFileType != "3gp" && $imageFileType != "ogg")
 {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";

    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "<script>alert('Not a valid Image');
window.location='add_package.php'</script>";
// if everything is ok, try to upload file
} else {
   move_uploaded_file($_FILES["file"]["tmp_name"], $target_file1);
    $photo=$i.$_FILES["file"]["name"];

$Lic_No="";
 $sql="select * from tbl_travels where login_id=$logid";
$res= mysqli_query($con,$sql);
while($row=mysqli_fetch_array($res))
{
 $Lic_No=$row["Lic_No"];
}

$vehicle=$_POST["vehicle"];
$amount=$_POST["amount"];
$vnumber=$_POST["vnumber"];
$scapacity=$_POST["scapacity"];
 $qry= mysqli_query($con,"insert into tbl_travel_packages(Vehicle_Type,Vehicle_number, km_amount, image, Lic_No,Seating_capacity)values('$vehicle','$vnumber',$amount,'$photo','$Lic_No',$scapacity)");

echo mysqli_error($con);
echo "<script>alert('Added successful......');
window.location='add_package.php'</script>";
}
?>