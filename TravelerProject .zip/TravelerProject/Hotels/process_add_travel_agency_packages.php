
<?php
session_start();
$logid=$_SESSION["slogid"];
include('../connect.php');

$i = 0; 
    $dir = 'package_uploads/';
    if ($handle = opendir($dir)) {
        while (($file = readdir($handle)) !== false){
            if (!in_array($file, array('.', '..')) && !is_dir($dir.$file)) 
                $i++;
        }
    }
  
$target_dir = "package_uploads/";
 $target_file = $target_dir . basename($_FILES["file"]["name"]);
$uploadOk = 1;
echo $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
 $target_file1 = $target_dir .$i. basename($_FILES["file"]["name"]);

// Check file size
if ($_FILES["file"]["size"] >100000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" && $imageFileType != "mov" && $imageFileType != "mp4" && $imageFileType != "3gp" && $imageFileType != "ogg")
 {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";

    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "<script>alert('Not a valid Image');
window.location='addhotel.php'</script>";
// if everything is ok, try to upload file
} else {
   move_uploaded_file($_FILES["file"]["tmp_name"], $target_file1);
    $photo=$i.$_FILES["file"]["name"];

$Lic_No="";
 $sql="select * from tbl_travel_agency where login_id=$logid";
$res= mysqli_query($con,$sql);
while($row=mysqli_fetch_array($res))
{
 $Lic_No=$row["Lic_No"];
}

$place_id=$_POST["Place"];
$num_members=$_POST["num_members"];
$num_days=$_POST["num_days"];
$num_nights=$_POST["num_nights"];
$stay_amount=$_POST["stay_amount"];
$food_amount=$_POST["food_amount"];
$bus_amount=$_POST["bus_amount"];
$train_amount=$_POST["train_amount"];
$description=$_POST["description"];


$state=$_POST["state"];
$district=$_POST["district"];
 $qry= mysqli_query($con,"insert into tbl_travel_agency_packages(Lic_No ,  Place_id ,  Members ,  Description,S_amount,F_amount,B_amount,T_amount,No_days,No_nights ,  Images)values('$Lic_No',$place_id,$num_members,'$description',$stay_amount,$food_amount,$bus_amount,$train_amount,$num_days,$num_nights,'$photo')");

echo mysqli_error($con);
echo "<script>alert('Added successful......');
window.location='add_package.php'</script>";
}
?>