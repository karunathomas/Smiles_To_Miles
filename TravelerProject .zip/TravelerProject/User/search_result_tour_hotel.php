<!DOCTYPE HTML>
<!--
	Aesthetic by gettemplates.co
	Twitter: http://twitter.com/gettemplateco
	URL: http://gettemplates.co
-->
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Traveler </title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Website Template by GetTemplates.co" />
	<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
	<meta name="author" content="GetTemplates.co" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="../css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="../css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="../css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="../css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="../css/magnific-popup.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="../css/bootstrap-datepicker.min.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="../css/style.css">

	<!-- Modernizr JS -->
	<script src="../js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="gtco-loader"></div>
	
	<div id="page">

	
	<!-- <div class="page-inner"> -->
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			
			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div id="gtco-logo"><a href="index.php">let's wonder where the wi-fi is weak <em></em></a></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					<ul>
	<li><a href="index.php">Home</a></li>
	<li ><a href="view_profile.php">Profile</a></li>
								
								<li class="has-dropdown ">
							<a>Booking</a>
							<ul class="dropdown">
								<li><a href="booking_travel_Agency.php">Travel Agency</a></li>
								<li><a href="booking_travels.php">Travels</a></li>
								<li><a href="booking_hotels.php">Hotels</a></li>
								
							</ul>
						</li>
						<li class="active"><a href="tour_planner.php">Tour Planner</a></li>
								<li><a href="change_password.php">Change Password</a></li>
									<li><a href="rating.php">Rating</a></li>
								<li><a href="../logout.php">Logout</a></li>
		</ul>	
				</div>
			</div>
			
		</div>
	</nav>
	<?php
$place=strtoupper($_GET["place"]);
include('../connect.php');

$res= mysqli_query($con,"select count(*) as c from tbl_site_info where UPPER(site_name) like '%$place%' or UPPER(site_address) like '%$place%'");
$count_site=0;
while($row=mysqli_fetch_array($res))
{
$count_site=$row["c"];
}
$res1= mysqli_query($con,"select count(*) as c from tbl_hotel_info where UPPER(hotel_address) like '%$place%'");
$count_hotel=0;
while($row=mysqli_fetch_array($res1))
{
$count_hotel=$row["c"];
}
	?>
	
	<header id="gtco-header" class="gtco-cover gtco-cover-md" role="banner" style="background-image:url(../images/goapic.jpg); height: 500px;">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">
					

					<div class="row row-mt-15em">
						<div class="col-md-7 mt-text animate-box" data-animate-effect="fadeInUp">
							<h1><strong><em><font size="10" face="Remachine Script Personal Use">SMILES TO MILES.....</font></em></strong></h1>	
						</div>
						<div class="col-md-4 col-md-push-1 animate-box" data-animate-effect="fadeInRight">
							<div class="form-wrap">
								<div class="tab">
                             <fieldset>
                                 <legend><font color="#FFFFFF"><?php echo strtoupper($place) ?></font></legend>
                                <input type='hidden' name='submitted' id='submitted' value='1'/>
                               <font color="#FFFFFF"> </font>
                              <font color="#000000"> 
                                </font>
                                
                           <font color="#FFFFFF">     <label name="u"><a  href="search_result_tour_hotel.php?place=<?php echo $_GET['place'] ?>">HOTELS(<?php echo $count_hotel; ?>) </a></label></font></br>
                               <font color="#FFFFFF"> <label name="p"><a href="search_result_tour_place.php?place=<?php echo $_GET['place'] ?>">PLACES TO VISIT(<?php echo $count_site ?>)</a></label></font></br>
 
                              </fieldset>  </header>
			<div class="gtco-section">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2><?php echo $place?></h2>
					<?php if($count_hotel==0)
{ ?>
<div class="btn btn-primary">No Hotels Available</div>
<?php } ?>
				</div>
			</div>
			<div class="row">
<?php $res2= mysqli_query($con,"select * from tbl_hotel_info where UPPER(hotel_address) like '%$place%'");
 while($row=mysqli_fetch_array($res2))
{
?>
				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="../admin/site_uploads/<?php echo $row['filename']; ?>" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="../admin/hotel_uploads/<?php echo $row['filename']; ?>" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2><?php echo strtoupper($row['Hotel_name']); ?></h2><p><font color="#000099"><?php echo ucfirst($row['hotel_address']); ?></font></p>
                            <p><font color="#000000"><?php echo $row['description']; ?></font></p>
						</div>
					</a>
				</div>
				
		<?php } ?>		

			</div>
		</div>
	</div>
	
	<div id="gtco-features">
		<!--<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading animate-box"></div>
			</div>
            <div class="row">
				<div class="col-md-4 col-sm-6">
					<!--<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i>1</i>
						</span>
						<h3>Travel Agency</h3>
						<p>Various travel agencies in india is registered in our website
                        </p>
					</div>
				</div>
				<div class="col-md-4 col-sm-6">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i>2</i>
						</span>
						<h3>Travels</h3>
						<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
					</div>
				</div>
				<div class="col-md-4 col-sm-6">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i>3</i>
						</span>
						<h3>Hotels</h3>
						<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
					</div>-->    
                
             </div>
		</div>
	</div>


	
			<div class="row copyright">
				<div class="col-md-12">
					<p class="pull-left">
						<small class="block"All Rights Reserved.</small> 
						
					</p>
					<p class="pull-right">
						<ul class="gtco-social-icons pull-right">
							<li><a href="#"><i class="icon-twitter"></i></a></li>
							<li><a href="#"><i class="icon-facebook"></i></a></li>
							<li><a href="#"><i class="icon-linkedin"></i></a></li>
							<li><a href="#"><i class="icon-dribbble"></i></a></li>
						</ul>
					</p>
				</div>
			</div>

		</div>
	</footer>
	<!-- </div> -->

	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<script src="../js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="../js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="../js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="../js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="../js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="../js/jquery.countTo.js"></script>

	<!-- Stellar Parallax -->
	<script src="../js/jquery.stellar.min.js"></script>

	<!-- Magnific Popup -->
	<script src="../js/jquery.magnific-popup.min.js"></script>
	<script src="../js/magnific-popup-options.js"></script>
	
	<!-- Datepicker -->
	<script src="../js/bootstrap-datepicker.min.js"></script>
	
<script src="../js/main.js"></script>

	</body>
</html>

