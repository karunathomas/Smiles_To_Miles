<?php
include('connect.php');
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$phno=$_POST["phno"];
$password=$_POST["password"];

$email=$_POST["email"];

  $qry3="select * from tbl_login where User_id='$email'";

$res= mysqli_query($con,$qry3);
$n=mysqli_num_rows($res);

if($n==0)
{


$r=mysqli_query($con,"insert into tbl_login(User_id,Password,User_type,status) values('$email','$password','4','Approved')");
 $last_id = mysqli_insert_id($con);
  echo $qry1="insert into tbl_users(Email,F_name,L_name,Phone_number,login_id)values('$email','$fname','$lname',$phno,$last_id )";
$qry= mysqli_query($con,$qry1);
echo "<script>alert('registration successful.......please login to continue');
window.location='users.php'</script>";
}
else
{
echo "<script>alert('Email ID  Already Exist');
window.location='users.php'</script>";
}


?>