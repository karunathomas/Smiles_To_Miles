<?php
session_start();
$logid=$_SESSION["slogid"];
$user_id=$_POST["userid"];
$cpassword=$_POST["cpassword"];
$newpassword=$_POST["newpassword"];
include('../connect.php');

$res2= mysqli_query($con,"select count(*) as c from tbl_login where Password='$cpassword' and User_id='$user_id' and login_id=$logid");
$c=0;
while($row=mysqli_fetch_array($res2))
{
$c=$row["c"];
}

if($c>0)
{
$res= mysqli_query($con,"update tbl_login set Password='$newpassword' where Password='$cpassword' and User_id='$user_id' and login_id=$logid");
echo "<script>alert('Password is Changed Successfully......');
window.location='change_password.php'</script>";
}
else
{

echo "<script>alert('Wrong info......');
window.location='change_password.php'</script>";
}


?>