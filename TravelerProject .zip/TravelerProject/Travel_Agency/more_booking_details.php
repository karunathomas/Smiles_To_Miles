<?php 
session_start();
$logid=$_SESSION["slogid"];
?>
<!DOCTYPE HTML>
<!--
	Aesthetic by gettemplates.co
	Twitter: http://twitter.com/gettemplateco
	URL: http://gettemplates.co
-->
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Traveler </title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Website Template by GetTemplates.co" />
	<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
	<meta name="author" content="GetTemplates.co" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="../css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="../css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="../css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="../css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="../css/magnific-popup.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="../css/bootstrap-datepicker.min.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="../css/style.css">

	<!-- Modernizr JS -->
	<script src="../js/modernizr-2.6.2.min.js"></script>
	<script type="text/javascript" src="../Ajax/ajax.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="gtco-loader">
	 
	</div>
	
	<div id="page">

	
	<!-- <div class="page-inner"> -->
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			
			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div id="gtco-logo"><a href="index.html">let's wonder where the wi-fi is weak <em></em></a></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					<ul>
	<li><a href="index.php">Home</a></li>
	<li><a href="add_package.php">Package</a></li>
								<li class="active"><a href="booking.php">Booking</a></li>
								
								<li><a href="../logout.php">Logout</a></li>
		</ul>	
				</div>
			</div>
			
		</div>
	</nav>
	
	<header id="gtco-header" class="gtco-cover gtco-cover-sm" role="banner" style="background-image:url(../images/123.jpg)">
	  <div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">
					<div class="row row-mt-15em"><div class="col-md-7 mt-text animate-box" data-animate-effect="fadeInUp">
						
								</div>
					
				</div>
			</div>
		</div>
	</header>
	
	
	
	
	
	<div class="gtco-section border-bottom">
		<div class="gtco-container">
			<h3>Details Of Package</h3>
			<table class="table">
  
  <tbody>
<?php
include('../connect.php');
$booking_id=$_GET["booking_id"];

$res1= mysqli_query($con,"select * from tbl_users inner join tbl_booking on  tbl_users.login_id= tbl_booking.login_id where tbl_booking.booking_id=$booking_id");
$fname="";
$lname="";
$phonenum="";
$email="";
while($row1=mysqli_fetch_array($res1))
{
	$fname=$row1["F_name"];	 
	$lname=$row1["L_name"];
	$mail=$row1["Email"];	
	$phno=$row1["Phone_number"];		 
	}	 
$res= mysqli_query($con,"select * from tbl_booking  inner join tbl_travel_agency_packages on  tbl_booking.Package_id= tbl_travel_agency_packages.Travel_agency_package_id inner join  tbl_place on tbl_travel_agency_packages.Place_id=tbl_place.place_id inner join tbl_district on tbl_place.district_id=tbl_district.district_id inner join tbl_state on tbl_state.state_id=tbl_district.state_id inner join tbl_countries on tbl_countries.country_id=tbl_state.country_id where tbl_booking.booking_id=$booking_id");

while($row=mysqli_fetch_array($res))
{
	?>
	<tr style="font-size: 25px; font-weight: bold;color: #09C6AB">
<td><a href="#" class="btn btn-primary">Booked - Amount Paid Rs <?php echo $row["amount_paid"] ?>/-</a></td><td><a href="booking.php" class="btn btn-primary">Back</a></td></tr>

		
		<tr><td>Tour Place</td><td><?php echo $row["place"]; ?> ,<?php echo $row["district"]; ?>, <?php echo $row["state"]; ?>,<?php echo $row["country_name"]; ?></td>
<tr>
		<td>Number of Member</td><td><?php echo $row["Members"]; ?></td></tr>
		<tr><td>Description </td><td><?php echo $row["Description"]; ?></td></tr>
		<tr><td>Total Number of Days </td><td><?php echo $row["No_days"]; ?></td></tr>
		<tr><td>Total Number of Nights</td><td><?php echo $row["No_nights"]; ?></td></tr>
		<tr><td>Stay Amount</td><td><?php echo $row["S_amount"]; ?></td></tr>
		<tr><td>Food Amount</td><td><?php echo $row["F_amount"]; ?></td></tr>
		<tr><td>Bus Amount</td><td><?php echo $row["B_amount"]; ?></td></tr>
		<tr><td>Train Charges</td><td><?php echo $row["T_amount"]; ?></td></tr>
		<tr bgcolor="#09C6AB"><td colspan="2" style="color:#fff" >Details Of Customer</td></tr>
		

		<tr><td>First Name </td><td><?php echo $fname; ?></td></tr>
		<tr><td>Last Name </td><td><?php echo $lname; ?></td></tr>
		<tr><td>Email</td><td><?php echo $mail; ?></td></tr>
		<tr><td>Phone Number </td><td><?php echo $phno; ?></td></tr>



	<?php

}
?>
</tbody></table>
		</div>
	</div>

	<footer id="gtco-footer" role="contentinfo" style="padding: 0">
		<div class="gtco-container">
			

			<div class="row copyright">
				<div class="col-md-12">
					<p class="pull-left">
						<small class="block">&copy; 2016 Free HTML5. All Rights Reserved.</small> 
						<small class="block">Designed by Istrox</small>
					</p>
					
				</div>
			</div>

		</div>
	</footer>
	<!-- </div> -->

	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<script src="../js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="../js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="../js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="../js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="../js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="../js/jquery.countTo.js"></script>

	<!-- Stellar Parallax -->
	<script src="../js/jquery.stellar.min.js"></script>

	<!-- Magnific Popup -->
	<script src="../js/jquery.magnific-popup.min.js"></script>
	<script src="../js/magnific-popup-options.js"></script>
	
	<!-- Datepicker -->
	<script src="../js/bootstrap-datepicker.min.js"></script>
	
<script src="../js/main.js"></script>

	</body>
</html>

