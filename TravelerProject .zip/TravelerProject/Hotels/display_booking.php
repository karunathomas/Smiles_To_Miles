<?php 
session_start();
$logid=$_SESSION["slogid"];
$date=$_GET["date"]; 
$bd=explode("/", $date);
	echo $bd=$bd[2]."-".$bd[0]."-".$bd[1];
?>
<h3>Booking List</h3>
					<table class="table">
  <thead>
  <tr>
     <th>Number of Membars</th>
     <th>Description</th>
      <th>Amount Paid</th>
       <th>Tour Place</th>
         <th>Tour Date</th>
         <th>Booking Date</th>
        
       <th>More Details</th>
       
  </tr>
  </thead>
  <tbody>
<?php
include('../connect.php');
$res= mysqli_query($con,"select * from tbl_booking  inner join tbl_travel_agency_packages on  tbl_booking.Package_id= tbl_travel_agency_packages.Travel_agency_package_id inner join  tbl_place on tbl_travel_agency_packages.Place_id=tbl_place.place_id inner join tbl_district on tbl_place.district_id=tbl_district.district_id inner join tbl_state on tbl_state.state_id=tbl_district.state_id inner join tbl_countries on tbl_countries.country_id=tbl_state.country_id where tbl_travel_agency_packages.Lic_No=(select Lic_No from tbl_travel_agency where login_id=$logid) and tbl_booking.booking_type='Hotel'and tbl_booking.booking_date='$bd'");

while($row=mysqli_fetch_array($res))
{
	?>
	<tr><td><?php echo $row["Members"]; ?></td>
		<td><?php echo $row["Description"]; ?></td>
		<td><?php echo $row["amount_paid"]; ?></td>
		
		<td><?php echo $row["place"]; ?> ,<?php echo $row["district"]; ?>, <?php echo $row["state"]; ?>,<?php echo $row["country_name"]; ?></td>
		<td><?php echo $row["from_date"]; ?></td>
		<td><?php echo $row["booking_date"]; ?></td>
		<td><a href="more_booking_details.php?booking_id=<?php echo $row["booking_id"] ?>">More Details</a></td>
		
		

	</tr>

	<?php
}
?>
</tbody></table>