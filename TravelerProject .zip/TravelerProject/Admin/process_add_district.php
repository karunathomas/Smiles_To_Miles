<?php
include('../connect.php');
$state=$_POST["state"];
$district=$_POST["district"];
$qry= mysqli_query($con,"insert into tbl_district(district,state_id)values('$district',$state)");

echo mysqli_error($con);
echo "<script>alert('Added successful......');
window.location='add_district.php'</script>";
?>