<?php 
session_start();
$logid=$_SESSION["slogid"];
$place=$_GET["Place"];
$Rate=$_GET["Rate"];
$appdistance=$_GET["appdistance"];
$vehicle=$_GET["vehicle"];


$arry_rate=explode("-", $Rate);

?>
<h3>Package List</h3>
					<table class="table">
  <thead>
  <tr>
     <th>Traveler Location</th>
     <th>Type</th>
     <th>Number</th>
     <th>Amount/Km</th>
     
       <th>Seating Capacity</th>
       
        
       
        <th>Book Now</th>
         <th>More Details</th>
       
       
  </tr>
  </thead>
  <tbody>
<?php

include('../connect.php');
$res= mysqli_query($con,"select * from tbl_travel_packages  inner join tbl_travels on tbl_travel_packages.Lic_No=tbl_travels.Lic_No  inner join  tbl_place on tbl_travels.Place=tbl_place.place_id inner join tbl_district on tbl_place.district_id=tbl_district.district_id inner join tbl_state on tbl_state.state_id=tbl_district.state_id inner join tbl_countries on tbl_countries.country_id=tbl_state.country_id where tbl_travels.Place=$place and tbl_travel_packages.km_amount*$appdistance between $arry_rate[0] and $arry_rate[1] and  tbl_travel_packages.Vehicle_type='$vehicle'");
//where tbl_travel_agency.login_id=$logid

while($row=mysqli_fetch_array($res))
{
	?>
	<tr>
<td><?php echo $row["place"]; ?> ,<?php echo $row["district"]; ?>, <?php echo $row["state"]; ?>,<?php echo $row["country_name"]; ?></td>

		<td><?php echo $row["Vehicle_Type"]; ?></td>
		<td><?php echo $row["Vehicle_number"]; ?></td>
		<td><?php echo $row["km_amount"]*$appdistance; ?></td>
		<td><?php echo $row["Seating_capacity"]; ?></td>
		<td><img width="150" height="100" src="../Travels/package_uploads/<?php echo $row["image"]; ?>"></td>
		
		<td><a class="btn btn-primary" href="booking_travel_start_date.php?pkgid=<?php echo $row["travel_package_id"] ?>&amount=<?php echo $row["km_amount"]*$appdistance ?>">Book Now</a></td>
		<td><a class="btn btn-primary" href="more_travel_packages.php?pkgid=<?php echo $row["travel_package_id"] ?>&amount=<?php echo $row["km_amount"]*$appdistance ?>">More Details</a></td>
		

	</tr>

	<?php
}
?>
</tbody></table>
