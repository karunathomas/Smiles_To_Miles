<?php 
session_start();
$logid=$_SESSION["slogid"];
$date=$_GET["date"]; 
$bd=explode("/", $date);
	 $bd=$bd[2]."-".$bd[0]."-".$bd[1];
?>
<h3>Booking List</h3>
					<table class="table">
  <thead>
  <tr>
     <th>Number of Membars</th>
     <th>Description</th>
      <th>Amount Paid</th>
       <th>Tour Place</th>
         <th>Tour Date</th>
         <th>Booking Date</th>
        
       <th>More Details</th>
       
  </tr>
  </thead>
  <tbody>
<?php
include('../connect.php');
 $qry="select * from tbl_booking  inner join tbl_travel_packages on  tbl_booking.Package_id= tbl_travel_packages.travel_package_id inner join tbl_travels on tbl_travel_packages.Lic_No=tbl_travels.Lic_No where tbl_travel_packages.Lic_No=(select Lic_No from tbl_travels where login_id=$logid) and tbl_booking.booking_type='Travel' and tbl_booking.booking_date='$bd'";
$res= mysqli_query($con,$qry);

while($row=mysqli_fetch_array($res))
{
	?>
	<tr><td><?php echo $row["Vehicle_Type"]; ?></td>
		<td><?php echo $row["Vehicle_number"]; ?></td>
		<td><?php echo $row["amount_paid"]; ?></td>
		
	
		<td><?php echo $row["from_date"]; ?></td>
		<td><?php echo $row["booking_date"]; ?></td>
		<td><a href="more_booking_details.php?booking_id=<?php echo $row["booking_id"] ?>">More Details</a></td>
		
		

	</tr>


	<?php
}
?>
</tbody></table>