<?php
include('../connect.php');

$place_id=$_GET["place_id"];
$qry= mysqli_query($con,"delete from tbl_place where place_id=$place_id");

echo mysqli_error($con);
echo "<script>alert('Deleted  successfully......');
window.location='add_place.php'</script>";
?>