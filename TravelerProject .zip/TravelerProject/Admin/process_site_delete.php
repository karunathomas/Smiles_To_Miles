<?php
include('../connect.php');

$site_id=$_GET["site_id"];
$qry= mysqli_query($con,"delete from tbl_site_info where site_info_id=$site_id");

echo mysqli_error($con);
echo "<script>alert('Deleted  successfully......');
window.location='addsite.php'</script>";
?>