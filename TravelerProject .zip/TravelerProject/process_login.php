<?php 

session_start();
include('connect.php');
 $usr=$_POST['username'];
 $pswd=$_POST['password'];

   $qry="select * from tbl_login where User_id='$usr' and Password='$pswd'";
     
        $res=mysqli_query($con,$qry);
        
        $logid=0;
        $userid="";
        $utype=0;
       
 $c=mysqli_num_rows($res);
        while($row=mysqli_fetch_array($res))
        {
        	
        	$logid=$row["login_id"];
        	$userid=$row["User_id"];
        	$utype=$row["User_type"];
              $status=$row["status"]; 
        }

    //-------------------------------Set Session----------------------------------------------------//

       

$_SESSION["slogid"]=$logid;
$_SESSION["suname"]=$userid;



        //-------------------------------------------------------------------------------------------//

        if($c>0)
        {
            if($status=="Approved")
            {
                if($utype==0)
                {
             header("location:Admin/index.php");   
         }
         else if($utype==1)
         {
 header("location:Travel_agency/index.php");   
         }
         else if($utype==2)
         {
 header("location:Travels/index.php");   
         }
         else if($utype==3)
         {
 header("location:Hotels/index.php");   
         }
         else if($utype==4)
         {
 header("location:User/index.php");   
         }
         else
         {
             ?>
                <script type="">
                    alert("Invalid User");
                    window.location="index.php";

                </script>
            <?php 
         }
            }
            else
        {
            ?>
                <script type="">
                    alert("Waiting For Approval");
                    window.location="index.php";

                </script>
            <?php 
        }
            

}

        else
        {
        	?>
            	<script type="">
            		alert("Invalid User");
            		window.location="index.php";

            	</script>
            <?php 
        }
?>