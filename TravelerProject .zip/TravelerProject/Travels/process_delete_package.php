<?php
include('../connect.php');

$pkgid=$_GET["pkgid"];
$qry= mysqli_query($con,"delete from tbl_travel_packages where travel_package_id=$pkgid");

echo mysqli_error($con);
echo "<script>alert('Deleted  successfully......');
window.location='add_package.php'</script>";
?>