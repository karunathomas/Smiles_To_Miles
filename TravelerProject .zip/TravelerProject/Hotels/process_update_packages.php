
<?php
session_start();
$logid=$_SESSION["slogid"];
include('../connect.php');

$pkgid=$_POST["pkgid"];
$num_members=$_POST["num_members"];
$num_days=$_POST["num_days"];
$num_nights=$_POST["num_nights"];
$stay_amount=$_POST["stay_amount"];
$food_amount=$_POST["food_amount"];
$bus_amount=$_POST["bus_amount"];
$train_amount=$_POST["train_amount"];
$description=$_POST["description"];


 $qry= mysqli_query($con,"update  tbl_travel_agency_packages set  Members=$num_members,  Description='$description',S_amount=$stay_amount,F_amount=$food_amount,B_amount=$food_amount,T_amount=$train_amount,No_days=$num_days,No_nights=$num_nights where Travel_agency_package_id=$pkgid");

echo mysqli_error($con);
echo "<script>alert('Added successful......');
window.location='add_package.php'</script>";

?>