<?php
include('connect.php');
$taname=$_POST["t_name"];
$licno=$_POST["lic_no"];
$place=$_POST["Place"];
$password=$_POST["password"];
$ownername=$_POST["ownername"];
$email=$_POST["email"];

 $qry3="select * from tbl_travels where Lic_No=$licno";

$res= mysqli_query($con,$qry3);
$n=mysqli_num_rows($res);

if($n==0)
{


$r=mysqli_query($con,"insert into tbl_login(User_id,Password,User_type,status) values('$email','$password','2','Submitted')");
 $last_id = mysqli_insert_id($con);
 $qry1="insert into tbl_travels(Travel_name,Lic_No,Place,Owner_name,Owner_id,login_id)values('$taname',$licno,$place,'$ownername','$email', $last_id )";
$qry= mysqli_query($con,$qry1);
echo "<script>alert('registration successful.......please login to continue');
window.location='travels.php'</script>";
}
else
{
echo "<script>alert('Licence Number Already Exist');
window.location='travel.php'</script>";
}


?>